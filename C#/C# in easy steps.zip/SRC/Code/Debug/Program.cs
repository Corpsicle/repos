﻿int pass = 0;
int unit = 2;

for (int i = 0; i < 3; i++)
{
    pass = (pass + 1);
    unit = square(unit);
}

static int square(int num)
{
    return (num * num);
}
